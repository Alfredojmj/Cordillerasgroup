
import React from 'react';

interface FooterProps {
  onNavigate: (view: 'home' | 'privacy' | 'terms') => void;
}

const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleScrollClick = (id: string) => {
    onNavigate('home');
    setTimeout(() => {
      const element = document.getElementById(id);
      if (element) {
        const offset = 80;
        const bodyRect = document.body.getBoundingClientRect().top;
        const elementRect = element.getBoundingClientRect().top;
        const elementPosition = elementRect - bodyRect;
        const offsetPosition = elementPosition - offset;
        window.scrollTo({ top: offsetPosition, behavior: 'smooth' });
      }
    }, 100);
  };

  return (
    <footer className="bg-[#12110d] text-[#a1a1a1] pt-24 pb-12 border-t border-white/5">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 mb-20">
          {/* Left Side: Branding */}
          <div className="md:col-span-5">
            <div className="flex items-center gap-3 mb-2">
              <svg viewBox="0 0 100 80" className="w-6 h-6">
                <path d="M50 5 L15 75 L85 75 Z" fill="none" stroke="#C5A059" strokeWidth="6" />
                <path d="M50 22 L32 65 L68 65 Z" fill="#C5A059" />
              </svg>
              <span className="text-white font-black tracking-widest uppercase text-xl">
                Cordilleras Group
              </span>
            </div>
            {/* Updated Tagline: Single, bold descriptive line */}
            <p className="text-gray-400 font-bold text-[10px] md:text-xs uppercase tracking-[0.3em] pl-9">
              Venture Studio & Innovation Consulting
            </p>
          </div>

          {/* Right Side: Navigation Columns */}
          <div className="md:col-span-7 grid grid-cols-2 md:grid-cols-3 gap-8 md:gap-4">
            {/* Explore Column */}
            <div>
              <h4 className="text-white font-bold text-sm mb-8 uppercase tracking-widest">Explore</h4>
              <ul className="flex flex-col gap-4 text-sm font-medium">
                <li>
                  <button 
                    onClick={() => handleScrollClick('projects')} 
                    className="hover:text-white transition-colors text-left focus:outline-none"
                  >
                    Projects
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleScrollClick('services')} 
                    className="hover:text-white transition-colors text-left focus:outline-none"
                  >
                    Services
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => handleScrollClick('about')} 
                    className="hover:text-white transition-colors text-left focus:outline-none"
                  >
                    About
                  </button>
                </li>
              </ul>
            </div>

            {/* Legal Column */}
            <div>
              <h4 className="text-white font-bold text-sm mb-8 uppercase tracking-widest">Legal</h4>
              <ul className="flex flex-col gap-4 text-sm font-medium">
                <li>
                  <button 
                    onClick={() => onNavigate('privacy')} 
                    className="hover:text-white transition-colors text-left focus:outline-none"
                  >
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => onNavigate('terms')} 
                    className="hover:text-white transition-colors text-left focus:outline-none"
                  >
                    Terms of Service
                  </button>
                </li>
              </ul>
            </div>

            {/* Contact Column */}
            <div className="col-span-2 md:col-span-1">
              <h4 className="text-white font-bold text-sm mb-8 uppercase tracking-widest">Contact</h4>
              <ul className="flex flex-col gap-4 text-sm font-medium">
                <li>
                  <a href="mailto:info@cordillerasgroup.com" className="hover:text-white transition-colors break-words">
                    info@cordillerasgroup.com
                  </a>
                </li>
                <li className="text-gray-500 italic">
                  Indiana, USA
                </li>
              </ul>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="text-[11px] text-gray-600 uppercase tracking-[0.2em] font-bold">
            © 2026 CORDILLERAS GROUP LLC. ALL RIGHTS RESERVED.
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
