
import React, { useState, useEffect } from 'react';

interface NavbarProps {
  onHome: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onHome }) => {
  const [scrolled, setScrolled] = useState(false);
  const [logoError, setLogoError] = useState(false);

  useEffect(() => {
    const handleScrollState = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScrollState);
    return () => window.removeEventListener('scroll', handleScrollState);
  }, []);

  const handleNavClick = (id: string) => {
    onHome(); // Ensure we are on the home page first
    setTimeout(() => {
      const element = document.getElementById(id);
      if (element) {
        const offset = 80;
        const bodyRect = document.body.getBoundingClientRect().top;
        const elementRect = element.getBoundingClientRect().top;
        const elementPosition = elementRect - bodyRect;
        const offsetPosition = elementPosition - offset;

        window.scrollTo({
          top: offsetPosition,
          behavior: 'smooth'
        });
      }
    }, 100);
  };

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${scrolled ? 'bg-white shadow-xl py-2' : 'bg-transparent py-6'}`}>
      <div className="container mx-auto px-6 flex items-center justify-between">
        <div className="flex items-center">
          <button 
            onClick={onHome}
            className="block h-12 md:h-14 transition-transform hover:scale-105 duration-300 outline-none"
          >
            {!logoError ? (
              <img 
                src="3.png" 
                alt="Cordilleras Group LLC" 
                className="h-full w-auto object-contain"
                onError={() => setLogoError(true)}
              />
            ) : (
              <div className="flex items-center gap-3">
                <svg viewBox="0 0 100 80" className="h-full w-auto">
                  <path d="M50 5 L15 75 L85 75 Z" fill="none" stroke="#C5A059" strokeWidth="4" />
                  <path d="M50 20 L30 65 L70 65 Z" fill="#C5A059" />
                  <path d="M20 75 L80 75" stroke="#121212" strokeWidth="2" />
                </svg>
                <div className="flex flex-col -gap-1">
                  <span className="text-lg font-black tracking-tighter text-black uppercase leading-none">Cordilleras</span>
                  <span className="text-[10px] font-bold tracking-[0.3em] text-[#C5A059] uppercase">Group LLC</span>
                </div>
              </div>
            )}
          </button>
        </div>

        <div className="hidden md:flex items-center gap-10">
          <button 
            onClick={() => handleNavClick('about')}
            className={`text-xs font-bold uppercase tracking-[0.2em] transition-colors ${scrolled ? 'text-gray-800' : 'text-gray-900'} hover:text-[#C5A059]`}
          >
            About
          </button>
          <button 
            onClick={() => handleNavClick('services')}
            className={`text-xs font-bold uppercase tracking-[0.2em] transition-colors ${scrolled ? 'text-gray-800' : 'text-gray-900'} hover:text-[#C5A059]`}
          >
            Services
          </button>
          <button 
            onClick={() => handleNavClick('projects')}
            className="px-8 py-3 border-2 border-[#C5A059] text-[#C5A059] font-black text-xs uppercase tracking-[0.3em] hover:bg-[#C5A059] hover:text-white transition-all duration-500 rounded-sm"
          >
            Projects
          </button>
        </div>

        <div className={`md:hidden ${scrolled ? 'text-black' : 'text-gray-900'}`}>
          <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6h16M4 12h16m-7 6h7" />
          </svg>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
