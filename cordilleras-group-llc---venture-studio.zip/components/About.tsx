
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-32 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <span className="text-[#C5A059] font-bold tracking-[0.3em] uppercase text-xs mb-8 block">Who We Are</span>
          <h2 className="text-3xl md:text-5xl font-light leading-snug tracking-tight italic" style={{ color: '#333333' }}>
            "Cordilleras Group operates at the intersection of <span className="font-bold not-italic">Strategic Consulting</span> and <span className="font-bold not-italic">Venture Building</span>. We transform business complexity into operational clarity by combining proven management methodologies with the agility of modern digital innovation. We don't just advise; <span className="text-[#C5A059] font-bold not-italic">we build the future with you.</span>"
          </h2>
          <div className="mt-12 h-px w-24 bg-gray-100 mx-auto"></div>
        </div>
      </div>
    </section>
  );
};

export default About;