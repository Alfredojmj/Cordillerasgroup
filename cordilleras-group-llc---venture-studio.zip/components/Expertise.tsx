
import React from 'react';

const ExpertiseItem: React.FC<{ title: string; description: string; icon: React.ReactNode }> = ({ title, description, icon }) => (
  <div className="flex flex-col p-10 border border-gray-100 bg-white hover:border-[#C5A059] transition-colors group">
    <div className="mb-8 text-[#C5A059] group-hover:scale-110 transition-transform duration-300">
      {icon}
    </div>
    <h3 className="text-xl font-black text-black mb-4 uppercase tracking-tighter">{title}</h3>
    <p className="text-gray-600 leading-relaxed text-sm">
      {description}
    </p>
  </div>
);

const Expertise: React.FC = () => {
  return (
    <section id="services" className="py-24 bg-gray-50 mountain-pattern">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mb-16">
          <span className="text-[#C5A059] font-bold tracking-[0.2em] uppercase text-xs mb-4 block">The Consulting Side</span>
          <h2 className="text-4xl md:text-5xl font-black text-black mb-6 italic">Core Expertise</h2>
          <p className="text-gray-600 text-lg leading-relaxed">
            We partner with existing organizations to streamline operations and unlock latent growth through systematic innovation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-0">
          <ExpertiseItem 
            title="Strategic Management" 
            description="High-level advisory focused on organizational structure, long-term roadmapping, and operational clarity."
            icon={(
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
              </svg>
            )}
          />
          <ExpertiseItem 
            title="Digital Transformation" 
            description="Integrating modern AI, automation, and cloud systems to evolve legacy business models into digital leaders."
            icon={(
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            )}
          />
          <ExpertiseItem 
            title="Venture Building" 
            description="End-to-end support for new product launches, including technical validation, branding, and early-stage scaling."
            icon={(
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
            )}
          />
        </div>
      </div>
    </section>
  );
};

export default Expertise;
