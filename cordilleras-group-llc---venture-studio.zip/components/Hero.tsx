
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative min-h-[90vh] flex items-center pt-20 overflow-hidden bg-gray-50">
      {/* Abstract Geometric Background Lines */}
      <div className="absolute inset-0 opacity-10 pointer-events-none">
        <svg className="w-full h-full" viewBox="0 0 1440 800" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M0 800L480 300L720 500L1100 100L1440 400" stroke="#C5A059" strokeWidth="1" />
          <path d="M0 700L380 200L620 400L1000 0L1440 300" stroke="#C5A059" strokeWidth="0.5" />
          <path d="M200 800L600 400L800 600L1200 200L1440 500" stroke="#121212" strokeWidth="0.5" />
        </svg>
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl">
          <div className="flex items-center gap-4 mb-6">
            <div className="h-1 w-12 bg-[#C5A059]"></div>
            <span className="uppercase tracking-[0.4em] text-xs font-bold text-gray-500">Venture Studio & Innovation Consulting</span>
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black text-black leading-tight mb-8">
            Clarity, Innovation, <br />
            and <span className="text-[#C5A059]">Growth</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-600 font-medium max-w-2xl leading-relaxed mb-12">
            Venture support and innovation consulting for small and mid-size companies ready to grow with clarity, systems, and technology.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-6">
            <button className="bg-charcoal text-white px-10 py-5 font-bold uppercase tracking-widest text-sm hover:bg-gray-800 transition-all flex items-center group">
              Explore Our Ventures
              <svg className="w-5 h-5 ml-3 transform group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </button>
          </div>
        </div>
      </div>
      
      {/* Decorative side element */}
      <div className="absolute bottom-0 right-0 p-12 hidden lg:block">
        <div className="flex flex-col items-end opacity-20 transform rotate-90 origin-bottom-right">
          <span className="text-6xl font-black text-gray-200 uppercase tracking-tighter">CORDILLERAS</span>
        </div>
      </div>
    </section>
  );
};

export default Hero;
