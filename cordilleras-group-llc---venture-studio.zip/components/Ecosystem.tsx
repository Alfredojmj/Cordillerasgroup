
import React from 'react';

const Ecosystem: React.FC = () => {
  return (
    <section id="projects" className="py-24 bg-white relative">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div className="max-w-xl">
            <span className="text-[#C5A059] font-bold tracking-[0.2em] uppercase text-xs mb-4 block">The Ecosystem</span>
            <h2 className="text-4xl md:text-5xl font-black text-black">Current Initiatives</h2>
          </div>
          <p className="text-gray-500 max-w-sm text-sm uppercase tracking-widest leading-loose">
            Deploying capital and expertise to build industry-leading platforms.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Featured Card 1 (Larger) */}
          <div className="md:col-span-8 group relative bg-gray-50 overflow-hidden border border-gray-100 flex flex-col md:flex-row min-h-[400px]">
            <div className="md:w-1/2 relative overflow-hidden">
                <img 
                    src="https://picsum.photos/seed/tech1/800/800" 
                    alt="Validea.ai" 
                    className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700"
                />
                <div className="absolute inset-0 bg-charcoal/40 group-hover:bg-charcoal/10 transition-colors"></div>
            </div>
            <div className="md:w-1/2 p-10 flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-2 mb-4">
                    <span className="bg-[#C5A059] h-0.5 w-6"></span>
                    <span className="text-[#C5A059] font-bold text-xs uppercase tracking-widest">Active Venture</span>
                </div>
                <h3 className="text-3xl font-black text-black mb-4">Validea.ai</h3>
                <p className="text-gray-600 mb-8 leading-relaxed">
                  A specialized Business Idea Validator powered by advanced AI algorithms, helping entrepreneurs stress-test concepts before market entry.
                </p>
              </div>
              <button className="w-fit px-8 py-3 bg-charcoal text-white font-bold uppercase tracking-widest text-xs hover:bg-[#C5A059] transition-all">
                Launch App (Beta 1.0)
              </button>
            </div>
          </div>

          {/* Card 2 (Placeholder) */}
          <div className="md:col-span-4 group relative bg-charcoal p-10 flex flex-col justify-between border border-gray-800">
             <div className="absolute top-0 right-0 p-6 opacity-10">
                <svg className="w-24 h-24 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm0 10.99h7c-.53 4.12-3.28 7.79-7 8.94V12H5V6.3l7-3.11v8.8z"/>
                </svg>
             </div>
             <div>
                <span className="text-gray-500 font-bold text-xs uppercase tracking-widest mb-4 block">In Development</span>
                <h3 className="text-2xl font-black text-white mb-4 italic">Confidential Venture</h3>
                <p className="text-gray-400 mb-8 leading-relaxed text-sm">
                  A private initiative currently in the exploration and design phase.
                </p>
             </div>
             <div className="flex items-center gap-2 text-[#C5A059] font-bold uppercase tracking-widest text-xs">
                <span>Stealth Mode</span>
                <div className="h-1 w-1 bg-[#C5A059] rounded-full animate-pulse"></div>
             </div>
          </div>
        </div>

        <div className="mt-16 flex justify-center">
            <button className="group flex items-center gap-4 text-sm font-black uppercase tracking-[0.3em] text-gray-400 hover:text-black transition-all">
                View All Projects
                <span className="h-px w-12 bg-gray-200 group-hover:w-24 group-hover:bg-[#C5A059] transition-all"></span>
            </button>
        </div>
      </div>
    </section>
  );
};

export default Ecosystem;
